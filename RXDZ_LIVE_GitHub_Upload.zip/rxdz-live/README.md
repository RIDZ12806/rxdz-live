# RXDZ LIVE

Arabic RTL Next.js dashboard + Upstash Redis API + standalone TikTok worker.

## 1) Local setup
```bash
cp .env.example .env.local
npm install
npm run dev
```
Create an Upstash Redis database and copy its REST URL/token into `.env.local`.

## 2) Environment variables
- `DASHBOARD_PASSWORD`: dashboard password.
- `SESSION_SECRET`: long random secret for signed sessions.
- `WORKER_KEY`: shared secret used by the worker.
- `RXDZ_API_KEY`: shared secret used by the Roblox Lua poller.
- `UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN`: Upstash REST credentials.

Generate secrets locally with `openssl rand -hex 32`. Never commit `.env.local` or share the keys publicly.

## 3) Deploy site to Vercel
Import the repository into Vercel, add all variables above, deploy, then create Upstash Redis via Marketplace or supply existing REST credentials.

## 4) Deploy worker
Follow `worker/README.md`. Worker must be a separate always-on process, not a Vercel function.

## 5) Roblox
In `RXDZ_Roblox_Poller.lua`, set `SITE_URL` to the deployed site origin and `API_KEY` to the exact value of `RXDZ_API_KEY`. Enable HTTP Requests in Roblox game security settings.

## Important implementation notes
- Roblox pull is authenticated with `X-API-Key` and removes pending names.
- Worker endpoints use `X-Worker-Key`.
- Dashboard APIs require the signed `rxdz_session` cookie.
- Queue validation is centralized in `lib/store.ts`.
- Review and test the full deployment with a private test stream before production use.
