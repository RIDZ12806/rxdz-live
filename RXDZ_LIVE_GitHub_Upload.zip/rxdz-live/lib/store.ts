import { Redis } from '@upstash/redis';
export const redis = Redis.fromEnv();
export const KEYS = { state:'rxdz:state', queue:'rxdz:queue', pending:'rxdz:pending', accepted:'rxdz:accepted', rejected:'rxdz:rejected', stats:'rxdz:stats', settings:'rxdz:settings' };
export type Viewer = { tiktok:string; roblox:string; at:number };
export type Settings = { maxQueue:number; cooldownSeconds:number; blockedWords:string[]; rules:{duplicate:boolean;cooldown:boolean;queueLimit:boolean;blockedWords:boolean} };
export const defaultSettings:Settings = { maxQueue:50,cooldownSeconds:60,blockedWords:[],rules:{duplicate:true,cooldown:true,queueLimit:true,blockedWords:true} };
export async function getSettings():Promise<Settings>{ return {...defaultSettings,...(await redis.get<Partial<Settings>>(KEYS.settings) || {}),rules:{...defaultSettings.rules,...((await redis.get<Partial<Settings>>(KEYS.settings))?.rules||{})}}; }
export async function getState(){ return (await redis.get<any>(KEYS.state)) || {desired:'stopped',tiktokUsername:'',status:'disconnected',statusMessage:'',updatedAt:Date.now()}; }
export async function reject(reason:string,tiktok:string,comment:string){ await redis.lpush(KEYS.rejected,{tiktok,comment,reason,at:Date.now()}); await redis.ltrim(KEYS.rejected,0,29); return {ok:false,reason}; }
export async function enqueue(tiktokRaw:string, robloxRaw:string){
 const tiktok=tiktokRaw.trim().replace(/^@/,''); const roblox=robloxRaw.trim();
 if(!/^[A-Za-z0-9_.]{1,24}$/.test(tiktok)) return reject('invalid TikTok name',tiktokRaw,robloxRaw);
 if(!/^[A-Za-z0-9_]{3,20}$/.test(roblox)) return reject('invalid name',tiktok,roblox);
 const s=await getSettings();
 if(s.rules.duplicate && await redis.sismember(KEYS.pending,roblox.toLowerCase())) return reject('duplicate',tiktok,roblox);
 if(s.rules.cooldown && s.cooldownSeconds > 0 && await redis.exists(`rxdz:cooldown:${tiktok.toLowerCase()}`)) return reject('rate limited',tiktok,roblox);
 if(s.rules.queueLimit && await redis.llen(KEYS.queue)>=s.maxQueue) return reject('queue full',tiktok,roblox);
 if(s.rules.blockedWords && s.blockedWords.some(w=>w.trim() && roblox.toLowerCase().includes(w.trim().toLowerCase()))) return reject('blocked word',tiktok,roblox);
 const viewer:Viewer={tiktok,roblox,at:Date.now()};
 // Queue + pending are written together in a Redis transaction.
 const tx=redis.pipeline(); tx.rpush(KEYS.queue,viewer); tx.sadd(KEYS.pending,roblox.toLowerCase()); if(s.rules.cooldown && s.cooldownSeconds > 0) tx.set(`rxdz:cooldown:${tiktok.toLowerCase()}`,'1',{ex:s.cooldownSeconds}); tx.lpush(KEYS.accepted,viewer); tx.ltrim(KEYS.accepted,0,29); await tx.exec();
 return {ok:true,viewer};
}
export async function requireSecret(request:Request, header:string, env:string){ const supplied=request.headers.get(header)||''; const expected=process.env[env]||''; return !!expected && supplied.length===expected.length && (await import('node:crypto')).timingSafeEqual(Buffer.from(supplied),Buffer.from(expected)); }
export async function requireDashboard(){ const {cookies}=await import('next/headers'); const c=await cookies(); const token=c.get('rxdz_session')?.value||''; const secret=process.env.SESSION_SECRET||''; if(!token||!secret) return false; const [payload,sig]=token.split('.'); if(!payload||!sig)return false; const crypto=await import('node:crypto'); const expected=crypto.createHmac('sha256',secret).update(payload).digest('hex'); if(sig.length!==expected.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))return false; try{return JSON.parse(Buffer.from(payload,'base64url').toString()).exp>Date.now()}catch{return false} }
export function json(data:any,status=200){return Response.json(data,{status});}
