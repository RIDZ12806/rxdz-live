import crypto from 'node:crypto';
export function makeSession(){const payload=Buffer.from(JSON.stringify({exp:Date.now()+7*86400000})).toString('base64url');const sig=crypto.createHmac('sha256',process.env.SESSION_SECRET||'').update(payload).digest('hex');return `${payload}.${sig}`;}
