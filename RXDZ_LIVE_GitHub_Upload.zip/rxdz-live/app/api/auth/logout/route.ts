import {json} from '@/lib/store';export async function POST(){const r=json({ok:true});r.headers.append('Set-Cookie','rxdz_session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0');return r}
