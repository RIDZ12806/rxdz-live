# RXDZ LIVE TikTok Worker

خدمة Node.js مستقلة تبقى متصلة ببث TikTok وتدفع التعليقات إلى API الموقع.

## المتطلبات
- Node.js 20 أو أحدث.
- `SITE_URL` رابط موقع RXDZ LIVE.
- `WORKER_KEY` نفس المفتاح الموجود في Vercel.
- `EULER_API_KEY` اختياري إذا تطلب موفر التوقيع ذلك.

## التشغيل محليًا
```bash
cp .env.example .env
npm install
npm start
```

## النشر على Railway
1. أنشئ مشروعًا جديدًا واربط مستودع GitHub الذي يحتوي مجلد `worker`.
2. اجعل Root Directory هو `worker`.
3. أضف `SITE_URL` و`WORKER_KEY` في Variables. أضف `EULER_API_KEY` فقط إذا حصلت على مفتاح من Euler Stream وتحتاجه.
4. أمر التشغيل: `npm start`.
5. راقب السجلات حتى تظهر رسالة `RXDZ LIVE worker started` ثم حالة الاتصال.

## النشر على Render
1. أنشئ Background Worker جديدًا من المستودع.
2. Root Directory: `worker`.
3. Build Command: `npm install`.
4. Start Command: `npm start`.
5. أضف متغيرات البيئة نفسها.

## ملاحظات TikTok
يعتمد المشروع على `tiktok-live-connector` الحديث: `TikTokLiveConnection` و`WebcastEvent.CHAT`. في حدث التعليق، اسم صاحب التعليق يؤخذ من `event.user.displayId` والنص من `event.content`. قد تتغير واجهة TikTok أو مزود التوقيع؛ راجع التوثيق الرسمي للمكتبة قبل التحديث. البث العام لا يتطلب تسجيل دخول عادةً، وقد يتطلب التوقيع مفتاح Euler حسب حالة الاتصال ومزود التوقيع.
