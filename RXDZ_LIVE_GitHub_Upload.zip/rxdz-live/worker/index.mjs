import 'dotenv/config';
import { TikTokLiveConnection, WebcastEvent, ControlEvent } from 'tiktok-live-connector';

const { SITE_URL, WORKER_KEY, EULER_API_KEY } = process.env;
if (!SITE_URL || !WORKER_KEY) throw new Error('SITE_URL and WORKER_KEY are required');
const base = SITE_URL.replace(/\/$/, '');
let connection = null;
let connectedUsername = '';
let desiredUsername = '';
let connecting = false;
let reconnectAt = 0;
let failures = 0;
let stoppedByCommand = false;

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function api(path, options = {}) {
  const response = await fetch(`${base}${path}`, { ...options, headers: { 'content-type': 'application/json', 'X-Worker-Key': WORKER_KEY, ...(options.headers || {}) } });
  if (!response.ok) throw new Error(`${path}: HTTP ${response.status} ${await response.text()}`);
  return response.json();
}
async function report(status, message = '') {
  try { await api('/api/worker/status', { method: 'POST', body: JSON.stringify({ status, message: String(message).slice(0, 500) }) }); }
  catch (e) { console.error('Status report failed:', e.message); }
}
async function disconnect() {
  const old = connection; connection = null; connectedUsername = '';
  if (old) { try { await old.disconnect(); } catch (e) { console.warn('Disconnect:', e.message); } }
}
async function connect(username) {
  if (connecting || connection?.isConnected) return;
  connecting = true; stoppedByCommand = false;
  await report('connecting', `جاري الاتصال بـ @${username}`);
  const options = EULER_API_KEY ? { signApiKey: EULER_API_KEY } : {};
  const client = new TikTokLiveConnection(username, options);
  connection = client;
  client.on(ControlEvent.ERROR, ({ info, exception } = {}) => {
    const message = exception?.message || info || 'TikTok connection error';
    console.error(message);
    void report('error', message);
  });
  client.on(ControlEvent.DISCONNECTED, () => {
    if (connection === client && !stoppedByCommand) {
      connection = null; connectedUsername = ''; failures += 1;
      const delay = [5000, 10000, 30000, 60000][Math.min(failures - 1, 3)];
      reconnectAt = Date.now() + delay;
      void report('error', `انقطع الاتصال؛ إعادة المحاولة بعد ${delay / 1000} ثانية`);
    }
  });
  client.on(WebcastEvent.CHAT, event => {
    const tiktokName = event.user?.displayId || event.user?.uniqueId || '';
    const comment = event.content || '';
    if (!tiktokName || !comment) return;
    void api('/api/ingest', { method: 'POST', body: JSON.stringify({ tiktokName, comment }) })
      .then(result => { if (!result.ok) console.log('Comment rejected:', result.reason); })
      .catch(err => console.error('Ingest failed; continuing:', err.message));
  });
  try {
    await client.connect();
    if (connection !== client) { await client.disconnect(); return; }
    connectedUsername = username; failures = 0; reconnectAt = 0;
    await report('connected', `متصل ببث @${username}`);
    console.log(`Connected to @${username}`);
  } catch (e) {
    if (connection === client) connection = null;
    failures += 1;
    const delay = [5000, 10000, 30000, 60000][Math.min(failures - 1, 3)];
    reconnectAt = Date.now() + delay;
    await report('error', e.message || 'Connection failed');
    console.error('TikTok connect failed:', e.message);
  } finally { connecting = false; }
}

console.log('RXDZ LIVE worker started');
while (true) {
  try {
    const state = await api('/api/worker/state');
    const shouldRun = state.desired === 'running' && state.tiktokUsername;
    if (!shouldRun) {
      if (connection || connecting) { stoppedByCommand = true; await disconnect(); }
      desiredUsername = '';
    } else if (desiredUsername !== state.tiktokUsername) {
      stoppedByCommand = true; await disconnect(); desiredUsername = state.tiktokUsername;
      failures = 0; reconnectAt = 0;
    }
    if (shouldRun && !connection?.isConnected && !connecting && Date.now() >= reconnectAt) await connect(state.tiktokUsername);
  } catch (e) { console.error('Worker loop error:', e.message); }
  await sleep(3000);
}
