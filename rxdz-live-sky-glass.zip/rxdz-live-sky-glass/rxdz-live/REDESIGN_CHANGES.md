# RXDZ LIVE — Sky Blue Glassmorphism redesign (à relire avant fusion)

Rien n'a été déployé. Le dossier `original-backup/` contient une copie complète de l'archive reçue.

## Fichiers
| Fichier | Statut |
|---|---|
| `RXDZ_CONTROL_PRO_GLASS.zip` → `site/index.html` | **Modifié** (nouvelle interface ; script d'origine conservé, 1 seule ligne visuelle changée : pause des particules) |
| `RXDZ_CONTROL_PRO_GLASS.zip` → `site/overlay.html` | **Modifié** (rendu stylé uniquement si le lien contient `&style=` ; sinon comportement d'origine) |
| `RXDZ_CONTROL_PRO_GLASS.zip` → `site/cs-core.js` | **Ajouté** (moteur de style des commentaires, partagé aperçu + overlay) |
| `RXDZ_CONTROL_PRO_GLASS.zip` → `site/studio-pre.js` | **Ajouté** (génère les contrôles du studio ; doit s'exécuter avant le script d'origine) |
| `RXDZ_CONTROL_PRO_GLASS.zip` → `site/studio.js` | **Ajouté** (navigation, menus, notifications, préférences, studio) |
| `REDESIGN_CHANGES.md` | **Remplacé** (l'ancien rapport décrivait la première refonte violette) |
| `review-site/` | dossier de relecture = contenu de `site/` |
| `worker.js`, `package.json`, `README.md`, `.github/workflows/pages.yml`, `RXDZ_CONTROL_PRO_GLASS_FIXED (2).zip`, `railway/*`, `site/_redirects`, `README-AR.txt` | **Identiques octet pour octet** |

## Fonctions préservées (vérifiées par test navigateur avec une API simulée)
Connexion / session (`/api/admin/me`, `login`, `logout`), chargement et sauvegarde des noms (`/api/admin/config`), import en masse, bibliothèque DJ (liste, ajout, édition, suppression, upload, lecture, volume), contrôle DJ, réglages overlay (`/api/admin/overlay` : même charge utile), lien overlay, régénération du jeton. Tous les identifiants d'éléments et appels API d'origine sont inchangés. Les chaînes patchées par le workflow Pages (`fetch("/api/admin/dj/upload"`, `("/media/"+encodeURIComponent(x.audioFile))`, balise `<head>`) sont intactes ; les étapes du workflow ont été rejouées localement avec succès.

## Studio de mise en forme
- Couleurs nom / texte / fond / opacité / taille reprennent les champs **déjà enregistrés sur Railway** (`ovAccent`, `ovText`, `ovBg`, `ovOpacity`, `ovSize`).
- Polices, poids, bordures, rayon, ombre, néon, marges, animation, alignement, avatar : stockés uniquement dans `localStorage` (`rxdz_comment_style_v2`, `rxdz_comment_presets_v2`) et transmis à l'overlay via `&style=` dans le lien. Rien de nouveau n'est envoyé au backend.
- Après une modification : « حفظ الإعدادات » puis recopier le lien dans Streamingin / OBS.

## À tester / limites connues
1. Test réel sur GitHub Pages + Railway (je n'ai pas pu me connecter à votre backend).
2. Le `worker.js` fourni n'expose pas `/api/admin/overlay` ni `/api/overlay/feed` : sans ces routes, les commentaires TikTok n'arrivent pas dans l'overlay (déjà le cas avant). Les ajouter est une modification backend — non faite, en attente de votre accord.
3. Avatar : affiché seulement si le flux fournit `avatar` ou `profilePictureUrl`.
4. Les polices viennent de Google Fonts (connexion requise ; repli sans-serif sinon).
5. Le workflow Pages insère `<head>\n` avec un `\\n` littéral ; un « \n » visible peut apparaître en haut de page (défaut préexistant, non modifié).
6. Le lien overlay vaut `location.origin + "/overlay.html"` : sur un site projet (`/rxdz-live/`) le dossier peut manquer (préexistant, non modifié).
