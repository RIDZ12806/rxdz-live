# RXDZ LIVE — Frontend Redesign (review before merging)

## Files
| File | Status | What changed |
|---|---|---|
| `RXDZ_CONTROL_PRO_GLASS.zip` → `site/index.html` | **Modified** | New premium dark/neon dashboard design + new "Comment Studio" section. All original element IDs, buttons and JavaScript logic are kept (the original script is included unchanged apart from 3 tiny visual hooks listed below). |
| `RXDZ_CONTROL_PRO_GLASS.zip` → `site/overlay.html` | **Modified** | Loads the 6 fonts and, **only when the link contains `&style=...`**, draws comments with the chosen design. Without `style` it behaves exactly as before. |
| `REDESIGN_CHANGES.md` | **Added** | This file. |
| `worker.js`, `package.json`, `README.md`, `.github/workflows/pages.yml`, `RXDZ_CONTROL_PRO_GLASS_FIXED (2).zip` | Unchanged | Byte-for-byte identical. |
| Inside the zip: `README-AR.txt`, `site/_redirects`, `railway/worker.js`, `railway/package.json` | Unchanged | Byte-for-byte identical. |

## Small hooks added to the original dashboard script (visual only)
1. `update()` also toggles a `is-live` CSS class and the status bar width.
2. After `ovLoad()` / `ovSave()` set the overlay link, `csSyncUrl()` appends the saved comment design (`&style=...`).
3. Ambient particles use the new purple/cyan colours.

No API path, request body, response handling, login, token or cookie logic was changed.
The strings patched by the GitHub Pages workflow (`fetch("/api/admin/dj/upload"` and `("/media/"+encodeURIComponent(x.audioFile))`) and the `<head>` tag used for the Railway shim are kept, and the workflow steps were run against the new zip successfully.

## Comment Studio storage
- Active design: `localStorage["rxdz_comment_style_v1"]`; saved presets: `localStorage["rxdz_comment_presets_v1"]`.
- Nothing is sent to Railway or Redis. The design reaches the stream overlay through the overlay link (`&style=`), so after changing the design press "حفظ وتطبيق" and paste the new link into Streamingin.

## Things to know (not changed)
- The live `worker.js` has **no** `/api/admin/overlay` or `/api/overlay/feed` routes, so the TikTok comment overlay cannot receive comments from the server yet (this was already the case before the redesign). Adding these routes is a backend change and was not done.
- The overlay link is built as `location.origin + "/overlay.html"`. On a GitHub Pages project site (`/rxdz-live/`) that path may be missing the folder name. Left as-is.

## Safe rollout
1. Create a branch (e.g. `redesign`) and upload these files there. The Pages workflow only deploys from `main`, so the branch will not go live.
2. Review, then merge to `main` when approved — that push of the zip triggers the normal deploy.
