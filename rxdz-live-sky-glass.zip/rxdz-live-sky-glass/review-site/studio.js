/* RXDZ visual layer: navigation, glass menus, toasts, preferences and the Comment Appearance Studio.
   Runs AFTER the original dashboard script. It only calls existing functions/IDs; it adds no endpoints. */
(()=>{
const g=id=>document.getElementById(id),qa=(s,r=document)=>[...r.querySelectorAll(s)];
const ls={get(k){try{return JSON.parse(localStorage.getItem(k))}catch{return null}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{toast("تعذر حفظ التفضيلات في هذا المتصفح","err")}}};
function toast(m,t){const d=document.createElement("div");d.className="toast "+(t||"");d.textContent=m;g("toasts").append(d);setTimeout(()=>d.remove(),t==="err"?5500:3200)}
window.alert=m=>toast(String(m),/^(تعذر|فشل|تأكد|اكتب|أدخل|الحد|لم أجد|حجم)/.test(m)?"err":"ok");
/* soft loading bar around the original api() */
const _api=api;let pend=0;api=function(){pend++;g("bar").classList.add("on");return _api.apply(this,arguments).finally(()=>{if(--pend<=0){pend=0;g("bar").classList.remove("on")}})};
/* preferences (visual only) */
const pr={fx:true,motion:matchMedia("(prefers-reduced-motion: reduce)").matches,...(ls.get("rxdz_ui_v1")||{})};
function applyPr(){document.documentElement.dataset.fx=pr.fx?"on":"off";document.documentElement.dataset.motion=pr.motion?"reduce":"";g("prFx").checked=pr.fx;g("prMotion").checked=pr.motion}
g("prFx").onchange=e=>{pr.fx=e.target.checked;ls.set("rxdz_ui_v1",pr);applyPr()};g("prMotion").onchange=e=>{pr.motion=e.target.checked;ls.set("rxdz_ui_v1",pr);applyPr()};applyPr();
/* router: sidebar sections with animated transitions */
const pages=qa(".page"),links=qa(".side-nav a");
function go(id,sc){let t=g(id);if(!t){id="overview";t=g(id)}const pg=t.closest(".page");pages.forEach(p=>p.classList.toggle("show",p===pg));
 const [ti,k]=(pg.dataset.title||"").split("|");g("ptitle").textContent=ti;g("kick").textContent=k;
 links.forEach(a=>a.classList.remove("active"));(links.find(a=>a.getAttribute("href")==="#"+id&&(a.dataset.scroll||"")===(sc||""))||links.find(a=>a.getAttribute("href")==="#"+id))?.classList.add("active");
 document.body.classList.remove("nav-open");const tg=sc?g(sc):t;if(tg===pg.firstElementChild||tg===t&&t===pg)scrollTo({top:0});else tg.scrollIntoView({behavior:"smooth",block:"start"})}
links.forEach(a=>a.addEventListener("click",e=>{e.preventDefault();const id=a.getAttribute("href").slice(1);history.pushState(null,"","#"+id);go(id,a.dataset.scroll)}));
addEventListener("hashchange",()=>go(location.hash.slice(1)||"overview"));
g("burger").onclick=()=>document.body.classList.toggle("nav-open");g("scrim").onclick=()=>document.body.classList.remove("nav-open");
qa("[data-proxy]").forEach(b=>b.onclick=()=>g(b.dataset.proxy).click());
/* glass dropdown menus */
qa(".menu").forEach(m=>{m.firstElementChild.onclick=e=>{e.stopPropagation();qa(".open").forEach(o=>o!==m&&o.classList.remove("open"));m.classList.toggle("open")};m.querySelector(".menu-list").onclick=()=>m.classList.remove("open")});
document.addEventListener("click",e=>qa(".open").forEach(o=>o.contains(e.target)||o.classList.remove("open")));
addEventListener("keydown",e=>{if(e.key==="Escape")qa(".open").forEach(o=>o.classList.remove("open"))});
function gsel(sel){const w=document.createElement("div"),b=document.createElement("button"),l=document.createElement("div");w.className="gs";b.type="button";b.className="gs-btn secondary";l.className="gs-list";l.setAttribute("role","listbox");sel.hidden=true;sel.after(w);w.append(b,l);
 const font=sel.dataset.font;[...sel.options].forEach(o=>{const d=document.createElement("div");d.setAttribute("role","option");d.textContent=o.text;if(font)d.style.fontFamily=`"${o.value}",sans-serif`;d.onclick=()=>{sel.value=o.value;sel.dispatchEvent(new Event("input",{bubbles:true}));w.classList.remove("open");sel.sync()};l.append(d)});
 sel.sync=()=>{const o=sel.selectedOptions[0];b.textContent=o?o.text:"";if(font&&o)b.style.fontFamily=`"${o.value}",sans-serif`;[...l.children].forEach((d,i)=>d.setAttribute("aria-selected",sel.options[i].value===sel.value))};
 b.onclick=e=>{e.stopPropagation();qa(".open").forEach(o=>o!==w&&o.classList.remove("open"));w.classList.toggle("open")};
 b.onkeydown=e=>{if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();const i=Math.max(0,Math.min(sel.options.length-1,sel.selectedIndex+(e.key==="ArrowDown"?1:-1)));sel.selectedIndex=i;sel.dispatchEvent(new Event("input",{bubbles:true}));sel.sync()}};sel.sync()}
/* modal (name prompt / confirm) */
function modal(title,val,ask){return new Promise(res=>{const m=g("modal"),i=g("mInput");g("mTitle").textContent=title;i.hidden=!ask;i.value=val||"";m.hidden=false;ask&&i.focus();const done=v=>{m.hidden=true;g("mYes").onclick=g("mNo").onclick=i.onkeydown=null;res(v)};g("mYes").onclick=()=>done(ask?(i.value.trim()||null):true);g("mNo").onclick=()=>done(ask?null:false);i.onkeydown=e=>{if(e.key==="Enter")g("mYes").click();if(e.key==="Escape")g("mNo").click()}})}
/* ---- Comment Appearance Studio ---- */
RXS.inject();const D=RXS.D;
const C=window.__csC,box=g("csControls");
qa("select",box).forEach(gsel);
const rd=k=>{const e=C[k];return e.dataset.t==="chk"?+e.checked:e.dataset.t==="rng"?+e.value:e.value};
function wr(){for(const k in C){const e=C[k],v=S[k];if(e.dataset.t==="chk")e.checked=!!v;else e.value=v;e.sync&&e.sync();if(e.dataset.t==="rng"){const o=e.id==="ovSize"?g("szv"):e.id==="ovOpacity"?g("opv"):g("cv_"+k);o.textContent=v+e.dataset.u}}}
const SK="rxdz_comment_style_v2",PK="rxdz_comment_presets_v2";
let S=RXS.norm(ls.get(SK)||RXS.D),sel="sky",act=null,custom=Array.isArray(ls.get(PK))?ls.get(PK).filter(p=>p&&p.id&&p.name).map(p=>({id:String(p.id),name:String(p.name).slice(0,40),style:RXS.norm(p.style)})):[],base="";
const ps=id=>P0(id)||{};const P0=id=>{const c=custom.find(x=>x.id===id);if(c)return c.style;return RXS.P[id]?RXS.preset(id):null};
const SAMPLES=[["سارة_RX","مرحباً بالجميع في البث المباشر 🔥"],["Rixo_Fan","Let's gooo, amazing stream! 🚀"],["أحمد","الرقصة رائعة — Dance 39 💙"]];
const stage=g("stage");let bgm=0;
function paint(anim){stage.style.setProperty("--g",S.gap+"px");stage.replaceChildren();SAMPLES.forEach(([n,t],i)=>{const el=RXS.bubble(S,{nick:n,text:t});if(anim)el.style.animationDelay=i*140+"ms",el.style.animationFillMode="backwards";else el.style.animation="none";stage.append(el)});g("pvNote").textContent=S.av?"الصورة الرمزية تظهر في العرض الحقيقي فقط إذا وفّر الخادم avatar أو profilePictureUrl في بيانات التعليق؛ هنا تظهر الحرف الأول.":""}
function sync(){g("ovAnimation").value=S.anim==="fade"?"fade":"slide";ls.set(SK,S);if(base)g("ovUrl").value=base+"&style="+RXS.enc(S);paint(false)}
function drawPresets(){const root=g("presets");root.replaceChildren();[...Object.keys(RXS.P).map(k=>({id:k,name:RXS.P[k].n,b:1})),...custom].forEach(p=>{const c=document.createElement("button");c.type="button";c.className="pcard"+(p.id===sel?" sel":"")+(p.id===act?" act":"");const m=document.createElement("div");m.className="mini";m.append(RXS.bubble(P0(p.id),{nick:"RX",text:"Hello"}));const n=document.createElement("b");n.textContent=p.name;const s=document.createElement("small");s.textContent=p.b?"مدمج":"مخصص";c.append(m,n,s);c.onclick=()=>{sel=p.id;drawPresets();ctl()};c.ondblclick=()=>g("csApply").click();root.append(c)});ctl()}
function ctl(){const cu=custom.some(c=>c.id===sel);g("csRename").disabled=g("csDel").disabled=!cu}
const nm=id=>(custom.find(c=>c.id===id)||{name:RXS.P[id]&&RXS.P[id].n}).name;
const saveC=()=>ls.set(PK,custom);
function setStyle(s,msg){S=RXS.norm(s);wr();sync();msg&&toast(msg,"ok")}
function input(){S=RXS.norm(Object.fromEntries(Object.keys(C).map(k=>[k,rd(k)])));sync()}
box.addEventListener("input",input);box.addEventListener("change",input);
g("csApply").onclick=()=>{act=sel;setStyle(P0(sel),"تم تطبيق «"+nm(sel)+"» — اضغط «حفظ الإعدادات» لإرسال الألوان إلى Railway");drawPresets()};
g("csSave").onclick=async()=>{const n=await modal("اسم القالب الجديد",act&&custom.some(c=>c.id===act)?nm(act):"قالب مخصص",1);if(!n)return;const ex=custom.find(c=>c.name.toLowerCase()===n.toLowerCase());if(ex){if(!await modal("استبدال القالب «"+n+"»؟",0,0))return;ex.style={...S};sel=act=ex.id}else{const p={id:"c"+Date.now(),name:n,style:{...S}};custom.push(p);sel=act=p.id}saveC();drawPresets();toast("تم حفظ القالب «"+n+"»","ok")};
g("csRename").onclick=async()=>{const c=custom.find(x=>x.id===sel);if(!c)return;const n=await modal("اسم جديد للقالب",c.name,1);if(!n)return;c.name=n;saveC();drawPresets();toast("تمت إعادة التسمية","ok")};
g("csDup").onclick=()=>{const s=P0(sel);if(!s)return;const p={id:"c"+Date.now(),name:(nm(sel)+" (نسخة)").slice(0,40),style:{...s}};custom.push(p);sel=p.id;saveC();drawPresets();toast("تم تكرار القالب","ok")};
g("csDel").onclick=async()=>{const c=custom.find(x=>x.id===sel);if(!c||!await modal("حذف القالب «"+c.name+"»؟",0,0))return;custom=custom.filter(x=>x!==c);if(act===c.id)act=null;sel="sky";saveC();drawPresets();toast("تم حذف القالب","ok")};
g("csReset").onclick=async()=>{if(!await modal("استعادة المظهر الافتراضي (Sky Blue Glass)؟",0,0))return;sel=act="sky";setStyle(RXS.preset("sky"),"تمت الاستعادة — اضغط «حفظ الإعدادات» لإرسال الألوان إلى Railway");drawPresets()};
g("pvReplay").onclick=()=>paint(true);g("pvDir").onclick=()=>{const r=stage.dir==="rtl";stage.dir=r?"ltr":"rtl";g("pvDir").textContent=r?"LTR":"RTL"};g("pvBg").onclick=()=>{bgm=(bgm+1)%3;stage.dataset.bg=bgm};
/* hook the original overlay functions: adopt server values, append &style= to the link */
const cap=()=>{const v=g("ovUrl").value;if(v)base=v.split("&style=")[0]};
const _ol=ovLoad;ovLoad=async function(){await _ol.apply(this,arguments);if(!g("ovUrl").value)return;cap();S=RXS.norm({...S,mColor:g("ovText").value,uColor:g("ovAccent").value,bg:g("ovBg").value,op:g("ovOpacity").value,size:g("ovSize").value});if((g("ovAnimation").value==="fade")!==(S.anim==="fade"))S.anim=g("ovAnimation").value;wr();sync();g("ovUrl").value=base+"&style="+RXS.enc(S)};
const _os=ovSave;ovSave=async function(){await _os.apply(this,arguments);cap();if(base)g("ovUrl").value=base+"&style="+RXS.enc(S)};
wr();paint(true);drawPresets();
const ink=location.hash.slice(1);go(ink||"overview");
})();
