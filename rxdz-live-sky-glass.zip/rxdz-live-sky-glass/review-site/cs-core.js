/* RXDZ comment style core — shared by the dashboard preview and overlay.html. Visual only; no network calls. */
(()=>{
const AR=["Cairo","Tajawal","Alexandria"],EN=["Orbitron","Rajdhani","Montserrat"];
const D={uAr:"Cairo",uEn:"Montserrat",mAr:"Cairo",mEn:"Montserrat",uColor:"#38bdf8",mColor:"#ffffff",bg:"#0b2236",bc:"#38bdf8",size:22,mW:500,uW:700,op:62,bw:1,r:16,sh:30,glow:25,px:16,py:10,gap:8,inner:8,bs:"full",anim:"slide",lay:"inline",al:"start",av:0};
const P={
sky:{n:"Sky Blue Glass"},
neon:{n:"Neon Cyan",uEn:"Rajdhani",mEn:"Rajdhani",uColor:"#22d3ee",bg:"#031b26",bc:"#22d3ee",op:70,bw:2,r:10,glow:70,uW:700,anim:"pop"},
game:{n:"Futuristic Gaming",uEn:"Orbitron",mEn:"Rajdhani",uColor:"#38bdf8",bg:"#06121f",bc:"#38bdf8",op:80,bw:3,bs:"side",r:6,glow:40,size:20,mW:600,lay:"stack"},
cyber:{n:"Cyberpunk",uEn:"Orbitron",mEn:"Rajdhani",uColor:"#f0abfc",mColor:"#e0f2fe",bg:"#120a22",bc:"#22d3ee",op:85,bw:2,r:2,glow:55,sh:60,anim:"rise",size:20},
min:{n:"Minimal Clean",uColor:"#7dd3fc",bg:"#0f172a",bc:"#7dd3fc",op:45,bw:0,r:12,glow:0,sh:20,uW:600,mW:400,anim:"fade"},
dark:{n:"Premium Dark Glass",uColor:"#bae6fd",bg:"#050d17",bc:"#38bdf8",op:78,bw:1,r:22,glow:12,sh:45,px:20,py:12,uW:600,lay:"stack",anim:"rise"},
elec:{n:"Electric Blue Glow",uEn:"Montserrat",uColor:"#60a5fa",bg:"#071a3a",bc:"#3b82f6",op:68,bw:2,r:18,glow:85,uW:800,anim:"pop"},
clear:{n:"Transparent Stream Overlay",uColor:"#7dd3fc",bg:"#000000",bc:"#7dd3fc",op:0,bw:0,r:8,glow:0,sh:90,mW:700,uW:800,px:8,py:4}};
const R={size:[14,40],mW:[300,900],uW:[300,900],op:[0,100],bw:[0,8],r:[0,40],sh:[0,100],glow:[0,100],px:[4,40],py:[2,30],gap:[0,30],inner:[0,20]};
const E={anim:["slide","fade","pop","rise","none"],lay:["inline","stack"],al:["start","center","end"],bs:["full","side"]};
function norm(s){const o={...D};if(!s||typeof s!=="object")return o;for(const k in D){const v=s[k];if(v==null)continue;
 if(R[k]){const n=+v;if(!isNaN(n))o[k]=Math.min(R[k][1],Math.max(R[k][0],Math.round(n)))}
 else if(E[k]){if(E[k].includes(v))o[k]=v}
 else if(k==="uAr"||k==="mAr"){if(AR.includes(v))o[k]=v}
 else if(k==="uEn"||k==="mEn"){if(EN.includes(v))o[k]=v}
 else if(k==="av")o[k]=v?1:0;
 else if(/^#[0-9a-f]{6}$/i.test(v))o[k]=v}
 return o}
const preset=k=>norm(P[k]);
const rgb=(h,a)=>{const n=parseInt(h.slice(1),16);return`rgba(${n>>16},${(n>>8)&255},${n&255},${a})`};
function vars(s){s=norm(s);const g=s.glow;return{"--uf":`"${s.uEn}","${s.uAr}",sans-serif`,"--mf":`"${s.mEn}","${s.mAr}",sans-serif`,"--uc":s.uColor,"--mc":s.mColor,"--uw":s.uW,"--mw":s.mW,"--size":s.size+"px","--bgc":rgb(s.bg,s.op/100),"--bc":s.bc,"--bw":s.bw+"px","--r":s.r+"px","--px":s.px+"px","--py":s.py+"px","--inner":s.inner+"px","--al":s.al,
 "--tsh":s.sh?`0 1px ${(s.sh*.1).toFixed(1)}px rgba(0,0,0,${(s.sh/100).toFixed(2)})`:"none",
 "--utsh":g?`0 0 ${(g*.2).toFixed(1)}px ${s.uColor},0 0 ${(g*.45).toFixed(1)}px ${rgb(s.uColor,.6)}`:"none",
 "--bx":g?`0 0 ${(g*.4).toFixed(1)}px ${rgb(s.bc,.55)},inset 0 0 ${(g*.15).toFixed(1)}px ${rgb(s.bc,.25)}`:"none"}}
function bubble(s,d){s=norm(s);const el=document.createElement("div");el.className=`rxdz-c l-${s.lay} b-${s.bs} a-${s.anim}`;
 const v=vars(s);for(const k in v)el.style.setProperty(k,v[k]);
 if(s.av){const a=d.avatar?document.createElement("img"):document.createElement("span");a.className="rxdz-av";if(d.avatar){a.src=d.avatar;a.alt=""}else a.textContent=(d.nick||"?").trim().charAt(0).toUpperCase();el.append(a)}
 const w=document.createElement("div");w.className="rxdz-w";const u=document.createElement("span");u.className="rxdz-u";u.textContent="@"+d.nick;const t=document.createElement("span");t.className="rxdz-t";t.textContent=d.text;w.append(u,t);el.append(w);return el}
const CSS=`.rxdz-c{display:flex;align-items:center;gap:10px;max-width:100%;box-sizing:border-box;padding:var(--py) var(--px);border-radius:var(--r);background:var(--bgc);color:var(--mc);font:var(--mw) var(--size)/1.5 var(--mf);text-shadow:var(--tsh);box-shadow:var(--bx);text-align:var(--al);overflow-wrap:anywhere}
.rxdz-c.b-full{border:var(--bw) solid var(--bc)}.rxdz-c.b-side{border-inline-end:var(--bw) solid var(--bc)}
.rxdz-w{display:flex;gap:var(--inner);min-width:0;flex:1}.l-inline .rxdz-w{flex-wrap:wrap;align-items:baseline}.l-stack .rxdz-w{flex-direction:column}
.rxdz-u{color:var(--uc);font-family:var(--uf);font-weight:var(--uw);text-shadow:var(--utsh)}.rxdz-t{font-family:var(--mf)}
.rxdz-av{width:2em;height:2em;border-radius:50%;object-fit:cover;flex:none;background:var(--uc);color:#04121f;display:grid;place-items:center;font:700 .9em var(--uf)}
@keyframes rxS{from{opacity:0;transform:translateX(-24px)}}@keyframes rxF{from{opacity:0}}@keyframes rxP{from{opacity:0;transform:scale(.8)}}@keyframes rxR{from{opacity:0;transform:translateY(18px)}}
.a-slide{animation:rxS .35s ease-out}.a-fade{animation:rxF .5s ease-out}.a-pop{animation:rxP .3s cubic-bezier(.2,1.4,.4,1)}.a-rise{animation:rxR .4s ease-out}`;
function inject(){if(document.getElementById("rxdz-cs"))return;const s=document.createElement("style");s.id="rxdz-cs";s.textContent=CSS;document.head.append(s);
 const l=document.createElement("link");l.rel="stylesheet";l.href="https://fonts.googleapis.com/css2?family=Cairo:wght@300..900&family=Tajawal:wght@300;400;500;700;800;900&family=Alexandria:wght@300..900&family=Orbitron:wght@400..900&family=Rajdhani:wght@300;400;500;600;700&family=Montserrat:wght@300..900&display=swap";document.head.append(l)}
const enc=s=>btoa(unescape(encodeURIComponent(JSON.stringify(norm(s))))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
const dec=t=>{try{t=t.replace(/-/g,"+").replace(/_/g,"/");return norm(JSON.parse(decodeURIComponent(escape(atob(t)))))}catch{return norm()}};
window.RXS={AR,EN,D,P,R,E,norm,preset,vars,bubble,inject,enc,dec,rgb};
})();
