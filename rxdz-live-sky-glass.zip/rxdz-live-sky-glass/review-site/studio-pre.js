/* RXDZ studio controls — built BEFORE the original dashboard script, which expects ids such as ovText/ovAccent/ovBg/ovOpacity/ovSize to exist. */
(()=>{const g=id=>document.getElementById(id);
const fo=a=>a.map(f=>[f,f]);
const SCHEMA=[["الخطوط",[["uAr","خط اسم المستخدم (عربي)","sel",fo(RXS.AR),"","",1],["uEn","خط اسم المستخدم (إنجليزي)","sel",fo(RXS.EN),"","",1],["mAr","خط التعليق (عربي)","sel",fo(RXS.AR),"","",1],["mEn","خط التعليق (إنجليزي)","sel",fo(RXS.EN),"","",1]]],
["الألوان",[["uColor","لون اسم المستخدم","col","","ovAccent"],["mColor","لون التعليق","col","","ovText"],["bg","لون الخلفية","col","","ovBg"],["bc","لون الحدود","col","","csBc"]]],
["الحجم والوزن",[["size","حجم الخط","rng",[14,40,"px"],"ovSize","szv"],["mW","وزن خط التعليق","rng",[300,900,""]],["uW","وزن اسم المستخدم","rng",[300,900,""]],["px","الحشو الأفقي","rng",[4,40,"px"]],["py","الحشو العمودي","rng",[2,30,"px"]],["gap","المسافة بين التعليقات","rng",[0,30,"px"]],["inner","المسافة بين الاسم والنص","rng",[0,20,"px"]]]],
["الخلفية والحدود",[["op","شفافية الخلفية","rng",[0,100,"%"],"ovOpacity","opv"],["bw","سماكة الحدود","rng",[0,8,"px"]],["r","استدارة الزوايا","rng",[0,40,"px"]],["bs","نمط الحدود","sel",[["full","إطار كامل"],["side","شريط جانبي"]]]]],
["التأثيرات",[["sh","ظل النص","rng",[0,100,""]],["glow","شدة التوهج (نيون)","rng",[0,100,""]],["anim","حركة الظهور","sel",[["slide","انزلاق"],["fade","تلاشي"],["pop","تكبير"],["rise","صعود"],["none","بدون"]]]]],
["التخطيط",[["lay","ترتيب الاسم والتعليق","sel",[["inline","في سطر واحد"],["stack","الاسم فوق التعليق"]]],["al","محاذاة النص","sel",[["start","بداية"],["center","وسط"],["end","نهاية"]]],["av","إظهار الصورة الرمزية","chk"]]]];
const C={};
const box=g("csControls");
SCHEMA.forEach(([t,items])=>{const s=document.createElement("section");s.className="cs-g glass";const h=document.createElement("h3");h.textContent=t;const r=document.createElement("div");r.className="cs-row";s.append(h,r);
 items.forEach(([k,lab,type,opt,id,out,font])=>{const w=document.createElement("div");let el;
  if(type==="rng"){const hd=document.createElement("div");hd.className="rg";const sp=document.createElement("span");sp.textContent=lab;const b=document.createElement("b");b.id=out||"cv_"+k;hd.append(sp,b);el=document.createElement("input");el.type="range";el.min=opt[0];el.max=opt[1];el.dataset.u=opt[2];w.append(hd,el);w.className="full"}
  else{const l=document.createElement("label");l.textContent=lab;w.append(l);if(type==="sel"){el=document.createElement("select");opt.forEach(([v,n])=>el.add(new Option(n,v)));if(font)el.dataset.font=1}else{el=document.createElement("input");el.type=type==="col"?"color":"checkbox"}w.append(el);if(type==="chk"){w.className="sw full";l.style.margin=0;w.prepend(l);w.append(el)}}
  el.id=id||"cs_"+k;el.dataset.k=k;el.dataset.t=type;C[k]=el;r.append(w)});box.append(s)});
window.__csC=C;})();
